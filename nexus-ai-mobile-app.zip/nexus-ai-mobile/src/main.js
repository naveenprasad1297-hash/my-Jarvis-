// The existing NEXUS AI prototype is bundled as a static asset for Capacitor.
// Vite copies www/index.html and its linked assets into dist during build.
import '../www/index.html';
