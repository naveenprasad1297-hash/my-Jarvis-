# NEXUS AI Mobile App Starter

This package wraps the existing responsive NEXUS AI prototype in Capacitor so it can be built as an Android app and, on macOS with Xcode, an iOS app.

## Requirements
- Node.js 20 or newer
- Android Studio + Android SDK for Android builds
- macOS + Xcode for iOS builds

## Build Android app
1. Extract this ZIP.
2. Open a terminal in the extracted `nexus-ai-mobile` folder.
3. Run:
   ```bash
   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. In Android Studio, wait for Gradle sync.
5. To test: select an emulator/device and press Run.
6. To create an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio will show the output path.

If `android/` already exists, skip `npx cap add android` and run `npx cap sync android`.

## Build iOS app
On a Mac with Xcode installed:
```bash
npm install
npm run build
npx cap add ios
npx cap sync ios
npx cap open ios
```
Select a simulator or signed device target in Xcode. App Store distribution requires an Apple Developer account and signing setup.

## Web preview
The existing responsive app is in `public/index.html`. For local preview, you can run a static server from the `public` folder, or deploy that file to a static host.

## Important limitations
- This is a mobile wrapper around the current frontend prototype, not a production backend.
- AI replies are local demo responses until a secure server-side AI provider is connected.
- Tasks, notes, and preferences currently use browser/WebView local storage; they do not sync across devices.
- Browser speech recognition support varies by platform and WebView. Native speech plugins or a supported speech API may be needed for reliable mobile voice input.
- Windows PC control, push notifications, real cloud memory, authentication, and integrations are not configured in this starter.
- Never place private AI API keys in the frontend.
