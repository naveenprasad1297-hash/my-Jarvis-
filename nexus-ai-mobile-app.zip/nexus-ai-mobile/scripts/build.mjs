import { cp, mkdir, readdir, rm } from 'node:fs/promises';

await rm('dist', { recursive: true, force: true });
await mkdir('dist', { recursive: true });
for (const entry of await readdir('public')) {
  await cp(`public/${entry}`, `dist/${entry}`, { recursive: true });
}
console.log('NEXUS AI web assets copied to dist/.');
