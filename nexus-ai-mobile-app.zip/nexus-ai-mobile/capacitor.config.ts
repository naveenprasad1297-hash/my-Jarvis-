import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.naveen.nexusai',
  appName: 'NEXUS AI',
  webDir: 'dist',
  bundledWebRuntime: false,
  backgroundColor: '#070707',
  android: {
    allowMixedContent: false
  },
  ios: {
    contentInset: 'automatic'
  }
};

export default config;
